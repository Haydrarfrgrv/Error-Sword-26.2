package com.haydraslowrmad.errorsword;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.world.item.CreativeModeTabs;

public class ErrorSwordMod implements ModInitializer {
    public static final String MOD_ID = "errorsword";

    @Override
    public void onInitialize() {
        ModItems.initialize();

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT)
                .register(entries -> entries.accept(ModItems.ERROR_SWORD));
    }
}
