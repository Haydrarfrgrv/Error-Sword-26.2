package com.haydraslowrmad.errorsword;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ToolMaterial;

import java.util.function.Function;

public final class ModItems {
    private ModItems() {}

    public static ResourceKey<Item> createKey(String name) {
        return ResourceKey.create(
                Registries.ITEM,
                ResourceLocation.fromNamespaceAndPath(ErrorSwordMod.MOD_ID, name)
        );
    }

    public static Item register(
            ResourceKey<Item> itemKey,
            Function<Item.Properties, Item> itemFactory,
            Item.Properties properties
    ) {
        Item item = itemFactory.apply(properties.setId(itemKey));
        return BuiltInRegistries.ITEM.register(itemKey, item);
    }

    public static final ResourceKey<Item> ERROR_SWORD_KEY = createKey("error_sword");

    /*
     * Minecraft's player has 1 base attack damage.
     * Netherite gives +3 attack damage.
     * The sword baseline below is 127998, giving:
     * 1 + 3 + 127998 = 128002 displayed attack damage.
     */
    public static final Item ERROR_SWORD = register(
            ERROR_SWORD_KEY,
            Item::new,
            new Item.Properties()
                    .rarity(Rarity.EPIC)
                    .sword(ToolMaterial.NETHERITE, 127998.0F, -2.4F)
    );

    public static void initialize() {
        // Forces static initialization.
    }
}
