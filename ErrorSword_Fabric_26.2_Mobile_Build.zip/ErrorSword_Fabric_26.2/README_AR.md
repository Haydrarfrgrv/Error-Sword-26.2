# Error Sword — Fabric 26.2

## المواصفات
- الاسم: **Error Sword**
- Minecraft Java: **26.2**
- Fabric Loader: **0.19.3**
- Fabric API: **0.158.0+26.2**
- الضرر المعروض: **128002**
- الشكل: بنفسجي + أسود، مستخرج من الصورة التي أرسلتها.
- لا توجد وصفة Crafting.
- يظهر في تبويب Combat في Creative.
- للحصول عليه بالأمر:

```text
/give @s errorsword:error_sword
```

## مهم
Minecraft 26.2 يحتاج Java 25 للتطوير والتشغيل وفق وثائق Fabric/Minecraft.

هذا المجلد هو **مشروع Fabric كامل المصدر**. لم أضع JAR وهمي؛ بناء JAR الحقيقي يحتاج Gradle مع تنزيل Minecraft/Fabric dependencies.

## البناء
بعد فتح المشروع في بيئة تدعم Gradle وJava 25:

```text
./gradlew build
```

وسيظهر ملف الـ JAR داخل:

```text
build/libs/
```
