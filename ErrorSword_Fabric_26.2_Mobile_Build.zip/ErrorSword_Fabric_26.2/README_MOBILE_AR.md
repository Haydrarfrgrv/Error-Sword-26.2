# Error Sword — بناء JAR من الموبايل 📱

هذه النسخة مجهزة لـ GitHub Actions حتى تستطيع بناء ملف JAR من الهاتف بدون تثبيت Java أو Gradle على الهاتف.

## الطريقة

1. أنشئ Repository جديد على GitHub.
2. ارفع محتويات هذا المجلد إلى الـRepository.
3. افتح تبويب **Actions**.
4. افتح **Build Error Sword**.
5. اضغط **Run workflow** أو ادفع أي تعديل وسيبدأ البناء تلقائيًا.
6. بعد انتهاء البناء افتح عملية الـworkflow الناجحة.
7. انزل إلى **Artifacts**.
8. نزّل **Error-Sword-JAR**.
9. فك ضغط الـArtifact وخذ ملف `error-sword-1.0.0.jar` وضعه في مجلد `mods` في Minecraft Java 26.2.

لا تحتاج تثبيت Java أو Gradle على الهاتف بهذه الطريقة؛ GitHub Actions هو الذي يشغّل Java 25 وGradle ويبني الـJAR.

المشروع يستهدف Minecraft 26.2، ويستخدم الإصدارات المنشورة على صفحة Fabric Develop: Loader 0.19.3 وFabric API 0.158.0+26.2 وLoom 1.18-SNAPSHOT. 
